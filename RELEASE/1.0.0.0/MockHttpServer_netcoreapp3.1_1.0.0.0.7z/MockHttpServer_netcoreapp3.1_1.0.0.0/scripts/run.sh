#!/bin/sh

clear

cd ..
./MockHttpServer.exe -port 8910 -pongPath 'C:\Users\cneves\source\repos\MockHttpServer\MockHttpServer\html'
